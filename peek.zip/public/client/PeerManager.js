// --- public/client/PeerManager.js ---
export class PeerManager {
    constructor(socket, ui) {
        this.socket = socket;
        this.ui = ui;
        this.peers = {};
        this.stream = null;
        this.peerId = null;
    }

    async handleSignal({ type, peerId, peers, from, payload }) {
        switch (type) {
            case 'init':
                this.peerId = peerId;
                this.stream = await navigator.mediaDevices.getDisplayMedia({ video: true, audio: false });
                this.ui.addStream('me', this.stream);
                peers.forEach(id => this.initiateConnection(id));
                break;

            case 'peer-joined':
                this.initiateConnection(peerId);
                break;

            case 'offer':
                this.receiveOffer(from, payload);
                break;

            case 'answer':
                this.receiveAnswer(from, payload);
                break;

            case 'ice-candidate':
                this.receiveCandidate(from, payload);
                break;

            case 'peer-left':
                this.removePeer(peerId);
                break;
        }
    }

    initiateConnection(peerId) {
        const pc = new RTCPeerConnection({ iceServers: [{ urls: 'stun:stun.l.google.com:19302' }] });
        this.peers[peerId] = pc;

        this.stream.getTracks().forEach(track => pc.addTrack(track, this.stream));

        pc.onicecandidate = (e) => {
            if (e.candidate) {
                this.send('ice-candidate', peerId, e.candidate);
            }
        };

        pc.ontrack = (e) => {
            this.ui.addStream(peerId, e.streams[0]);
        };

        pc.onconnectionstatechange = () => {
            if (pc.connectionState === 'disconnected') {
                this.removePeer(peerId);
            }
        };

        pc.createOffer()
            .then(offer => pc.setLocalDescription(offer))
            .then(() => {
                this.send('offer', peerId, pc.localDescription);
            });
    }

    receiveOffer(from, offer) {
        const pc = new RTCPeerConnection({ iceServers: [{ urls: 'stun:stun.l.google.com:19302' }] });
        this.peers[from] = pc;

        this.stream.getTracks().forEach(track => pc.addTrack(track, this.stream));

        pc.onicecandidate = (e) => {
            if (e.candidate) {
                this.send('ice-candidate', from, e.candidate);
            }
        };

        pc.ontrack = (e) => {
            this.ui.addStream(from, e.streams[0]);
        };

        pc.setRemoteDescription(new RTCSessionDescription(offer))
            .then(() => pc.createAnswer())
            .then(answer => pc.setLocalDescription(answer))
            .then(() => {
                this.send('answer', from, pc.localDescription);
            });
    }

    receiveAnswer(from, answer) {
        this.peers[from].setRemoteDescription(new RTCSessionDescription(answer));
    }

    receiveCandidate(from, candidate) {
        this.peers[from].addIceCandidate(new RTCIceCandidate(candidate));
    }

    removePeer(peerId) {
        const pc = this.peers[peerId];
        if (pc) pc.close();
        delete this.peers[peerId];
        this.ui.removeStream(peerId);
    }

    send(type, to, payload) {
        this.socket.send(JSON.stringify({ type, to, payload }));
    }
}