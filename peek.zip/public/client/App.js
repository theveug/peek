// --- public/client/App.js ---
import { PeerManager } from './PeerManager.js';
import { UIController } from './UIController.js';

const sessionId = location.pathname.split('/').pop();
const protocol = location.protocol === 'https:' ? 'wss' : 'ws';
const socket = new WebSocket(`${protocol}://${location.host}`);
const ui = new UIController();
const peerManager = new PeerManager(socket, ui);

socket.onopen = () => {
    socket.send(JSON.stringify({ type: 'join', sessionId }));
};

socket.onmessage = (event) => {
    const msg = JSON.parse(event.data);
    if (msg.type === 'chat') {
        ui.addChatMessage(msg.from, msg.text);
    } else {
        peerManager.handleSignal(msg);
    }
};

// Chat UI interactions
const input = document.getElementById('message');
const sendBtn = document.getElementById('send');
sendBtn.onclick = () => {
    const text = input.value.trim();
    if (text) {
        socket.send(JSON.stringify({ type: 'chat', text }));
        ui.addChatMessage('Me', text);
        input.value = '';
    }
};