// --- public/client/UIController.js ---
export class UIController {
    constructor() {
        this.container = document.getElementById('videos');
        this.chatLog = document.getElementById('chat-log');
    }

    addStream(peerId, stream) {
        let video = document.querySelector(`video[data-peer='${peerId}']`);
        if (!video) {
            video = document.createElement('video');
            video.autoplay = true;
            video.playsInline = true;
            video.dataset.peer = peerId;
            this.container.appendChild(video);
        }
        video.srcObject = stream;
    }

    removeStream(peerId) {
        const video = document.querySelector(`video[data-peer='${peerId}']`);
        if (video) video.remove();
    }

    addChatMessage(from, text) {
        const message = document.createElement('div');
        message.textContent = `${from}: ${text}`;
        this.chatLog.appendChild(message);
        this.chatLog.scrollTop = this.chatLog.scrollHeight;
    }
}